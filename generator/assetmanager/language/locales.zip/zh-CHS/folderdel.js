function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "\u786e\u5b9a\u5220\u9664\u6b64\u8d44\u6599\u5939 ?";

    document.getElementById("btnClose").value = "\u5173\u95ed ";
    document.getElementById("btnDelete").value = "\u5220\u9664 ";
	}
function writeTitle()
	{
	document.write("<title>Delete Folder</title>")
	}
