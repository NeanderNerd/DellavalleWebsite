function loadTxt()
    {
    document.getElementById("btnClose").value = "St\u00E4ng";
    }
function writeTitle()
    {
    document.write("<title>" + "F\u00F6rhandsgranska" + "</title>")
    }