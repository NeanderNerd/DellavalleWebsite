function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Namm";
    document.getElementById("btnCancel").value = "Avbryt";
    document.getElementById("btnInsert").value = "Infoga";
    document.getElementById("btnApply").value = "Verkst\u00E4ll";
    document.getElementById("btnOk").value = " OK ";
    }
function writeTitle()
    {
    document.write("<title>" + "Filf\u00E4lt" + "</title>")
    }