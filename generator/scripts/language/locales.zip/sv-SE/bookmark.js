function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Namn";
    document.getElementById("btnCancel").value = "Avbryt";
    document.getElementById("btnInsert").value = "Infoga";
    document.getElementById("btnApply").value = "Verkst\u00E4ll";
    document.getElementById("btnOk").value = " OK ";
    }
function writeTitle()
    {
    document.write("<title>" + "Bokm\u00E4rke" + "</title>")
    }