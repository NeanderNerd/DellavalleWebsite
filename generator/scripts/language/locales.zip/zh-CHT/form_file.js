function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "\u540d\u7a31 ";
    
    document.getElementById("btnCancel").value = "\u53d6\u6d88 ";
    document.getElementById("btnInsert").value = "\u63d2\u5165 ";
    document.getElementById("btnApply").value = "\u61c9\u7528 ";
    document.getElementById("btnOk").value = " \u78ba\u8a8d  ";
    }
function writeTitle()
    {
    document.write("<title>\u6a94\u6848\u6b04\u4f4d </title>")
    }