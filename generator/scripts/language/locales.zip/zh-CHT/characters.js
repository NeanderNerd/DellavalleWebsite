function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML\u6e90\u78bc ";
    document.getElementById("btnClose").value = "\u95dc\u9589 ";
    }
function writeTitle()
    {
    document.write("<title>\u7279\u6b8a\u5b57\u5143 </title>")
    }