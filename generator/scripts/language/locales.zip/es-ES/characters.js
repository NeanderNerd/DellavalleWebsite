function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "C&oacute;digo HTML";
    document.getElementById("btnClose").value = "Cerrar";
    }
function writeTitle()
    {
    document.write("<title>Caracteres Especiales</title>")
    }