function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Nombre";
    document.getElementById("btnCancel").value = "Cancelar";
    document.getElementById("btnInsert").value = "Insertar";
    document.getElementById("btnApply").value = "Aplicar";
    document.getElementById("btnOk").value = " Aplicar y salir ";
    }
function writeTitle()
    {
    document.write("<title>Anclaje</title>")
    }