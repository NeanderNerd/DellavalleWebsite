function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Pegar contenido desde Word aqui";
    document.getElementById("btnCancel").value = "Cancelar";
    document.getElementById("btnOk").value = " Aceptar ";   
	}
function writeTitle()
	{
	document.write("<title>Pegar desde Word</title>")
	}
