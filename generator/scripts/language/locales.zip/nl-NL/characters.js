function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML Code";
    document.getElementById("btnClose").value = "sluiten";
    }
function writeTitle()
    {
    document.write("<title>Speciale Karakters</title>")
    }