function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Naam";
    document.getElementById("btnCancel").value = "annuleren";
    document.getElementById("btnInsert").value = "invoegen";
    document.getElementById("btnApply").value = "toepassen";
    document.getElementById("btnOk").value = " ok ";
    }
function writeTitle()
    {
    document.write("<title>Bestand Veld</title>")
    }