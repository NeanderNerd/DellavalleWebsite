function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Couleur";
    document.getElementById("btnCancel").value = "Annuler";
    document.getElementById("btnOk").value = " ok ";
    }
function getTxt(s)
    {
    switch(s)
        {
        case "No Border": return "Sans Bordure";
        case "Outside Border": return "Bordures Externes";
        case "Left Border": return "Bordure Gauche";
        case "Top Border": return "Bordure Haute";
        case "Right Border": return "Bordure Droite";
        case "Bottom Border": return "Bordure Basse";
        case "Pick": return "Choisir";
        case "Custom Colors": return "Custom Colors";
        case "More Colors...": return "More Colors...";
        default: return "";
        }
    }
function writeTitle()
    {
    document.write("<title>Bordures</title>")
    }