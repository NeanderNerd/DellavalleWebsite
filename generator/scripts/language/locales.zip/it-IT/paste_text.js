function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Contenuto testo da incollare (CTRL-V) ";
    document.getElementById("btnCancel").value = "cancella";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Incolla Testo</title>")
	}
